package com.example.yash_tip_split_cal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.DecimalFormat;
import static java.lang.Math.ceil;

public class MainActivity extends AppCompatActivity {

    private EditText bill_total;
    private EditText tip_total;
    private EditText total_with_tip;
    private EditText no_of_people;
    private EditText total_per_person;
    private EditText overage;
    RadioGroup radioG;
    RadioButton radio12, radio15, radio18, radio20;
    //declare variables
    double percent=0;
    Double tip_total_double=0.0;
    DecimalFormat decimalFormat = new DecimalFormat("#.00");



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //declare variables
        bill_total = findViewById(R.id.bill_total);
        tip_total = findViewById(R.id.tip_total);
        total_with_tip = findViewById(R.id.total_with_tip);
        no_of_people = findViewById(R.id.no_of_people);
        total_per_person = findViewById(R.id.total_per_person);
        overage = findViewById(R.id.overage);
        radioG = findViewById(R.id.radioGroup);
        radio12 = findViewById(R.id.radiotwelve);
        radio15 = findViewById(R.id.radiofifteen);
        radio18 = findViewById(R.id.radioeighteen);
        radio20 = findViewById(R.id.radiotwenty);

    }


    //func1 - calculating tip
    public void calculate_tip(Double percent)
    {
        //convert the textview input to string first
        String bill_total_1 = bill_total.getText().toString();
        //convert this string to double by parse double
        Double double_type_bill_total = Double.parseDouble(bill_total_1);

        //if condn to check if input ==0 then unselect the radio group and other elements
        if(bill_total.getText().toString().isEmpty()){
            radioG.clearCheck();
            bill_total.setText("");
            tip_total.setText("");
            total_with_tip.setText("");
        }
        //else calculate the tip
        else {
            Double tip_total_1 = percent * double_type_bill_total;
            bill_total_1 = ("$" + decimalFormat.format(tip_total_1));
            tip_total.setText(bill_total_1);

            tip_total_double = double_type_bill_total + tip_total_1;
            String total_with_tip_1 = "$" + decimalFormat.format(tip_total_double);
            total_with_tip.setText(total_with_tip_1);
        }

    }

    //func 2 - calculating split
    @SuppressLint("SetTextI18n")
    public void calculate_split(View v){
        String people = no_of_people.getText().toString();
        int peoples = Integer.parseInt(people);

        //convert the textview input to string first
        String bill_total_2 = bill_total.getText().toString();
        //convert this string to double by parse double
        Double double_type_bill_total_2 = Double.parseDouble(bill_total_2);


        if(double_type_bill_total_2 == 0) {
            clearButtonClicked(v);
        }
        else if(double_type_bill_total_2 !=0 && tip_total.getText().toString().isEmpty() && total_with_tip.getText().toString().isEmpty()){
            Double per_person = double_type_bill_total_2/peoples;
            per_person = per_person * 10;
            per_person = ceil(per_person);
            per_person = per_person / 10;
            String string_per_person =  "$" + decimalFormat.format(per_person);
            total_per_person.setText(string_per_person);
            overage.setText("$0.00");
        }
        else{
            if (peoples == 0) {
                no_of_people.setText("");
                total_per_person.setText("");
                overage.setText("");
            } else {
                Double per_person = tip_total_double / peoples;
                per_person = per_person * 10;
                per_person = ceil(per_person);
                per_person = per_person / 10;
                String string_per_person = "$" + decimalFormat.format(per_person);
                total_per_person.setText(string_per_person);
                per_person = per_person * peoples;
                Double double_overage = per_person * 100 - tip_total_double * 100;
                double_overage = double_overage / 100;
                double_overage = Math.abs(double_overage);
                overage.setText("$0" + decimalFormat.format(double_overage));
            }
        }
    }


    //func 3 - radio clicked for defining percentage value
    public void radioButtonClicked(View v)
    {
        if(bill_total.getText().toString().isEmpty() && percent == 0)
        {
            radioG.clearCheck();
        }
        else {
            if (v.getId() == R.id.radiotwelve) {
                percent = 0.12;
            } else if (v.getId() == R.id.radiofifteen) {
                percent = 0.15;

            } else if (v.getId() == R.id.radioeighteen) {
                percent = 0.18;
            } else if (v.getId() == R.id.radiotwenty) {
                percent = 0.2;
            }
            //call func calculate_tip
            calculate_tip(percent);
        }
    }

    //func 4 - to clear all the input / output fields
    public void clearButtonClicked(View v){
        bill_total.setText("");
        radioG.clearCheck();
        tip_total.setText("");
        total_with_tip.setText("");
        no_of_people.setText("");
        total_per_person.setText("");
        overage.setText("");
    }

    //onSaveInstanceState func
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putString("BILL_TOTAL",bill_total.getText().toString());
        outState.putString("TIP_TOTAL",tip_total.getText().toString());
        outState.putString("TOTAL_WITH_TIP",total_with_tip.getText().toString());
        outState.putString("NO_OF_PEOPLE",no_of_people.getText().toString());
        outState.putString("TOTAL_PER_PERSON",total_per_person.getText().toString());
        outState.putString("OVERAGE",overage.getText().toString());
        outState.putDouble("TIP_TOTAL_DOUBLE",tip_total_double);
        outState.putBoolean("RADIO_12",radio12.isChecked());
        outState.putBoolean("RADIO_15",radio15.isChecked());
        outState.putBoolean("RADIO_18",radio18.isChecked());
        outState.putBoolean("RADIO_20",radio20.isChecked());
        super.onSaveInstanceState(outState);
    }


    //onRestoreInstanceState func
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        bill_total.setText(savedInstanceState.getString("BILL_TOTAL"));
        tip_total.setText(savedInstanceState.getString("TIP_TOTAL"));
        total_with_tip.setText(savedInstanceState.getString("TOTAL_WITH_TIP"));
        no_of_people.setText(savedInstanceState.getString("NO_OF_PEOPLE"));
        total_per_person.setText(savedInstanceState.getString("TOTAL_PER_PERSON"));
        overage.setText(savedInstanceState.getString("OVERAGE"));
        tip_total_double = savedInstanceState.getDouble("TIP_TOTAL_DOUBLE");
        radio12.setChecked(savedInstanceState.getBoolean("RADIO_12"));
        radio15.setChecked(savedInstanceState.getBoolean("RADIO_15"));
        radio18.setChecked(savedInstanceState.getBoolean("RADIO_18"));
        radio20.setChecked(savedInstanceState.getBoolean("RADIO_20"));
        super.onRestoreInstanceState(savedInstanceState);
    }
}